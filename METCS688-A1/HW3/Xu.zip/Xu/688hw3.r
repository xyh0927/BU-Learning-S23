# Load required package
library(tm)

# Load the dataset for my test
load("C:/Users/33351/Desktop/github/688hw3/NewsGroup_Dtm.RData")

# Load the "NewsGroup_Dtm.RData" file from the "Data" folder
load("Data/NewsGroup_Dtm.RData")

# Create a linear model using the natural logarithm of word frequency and rank
log_freq <- log(rowSums(dtm))   # Calculate the natural logarithm of word frequency
log_rank <- log(rank(-log_freq))   # Calculate the natural logarithm of rank
model <- lm(log_freq ~ log_rank)   # Create the linear model

# Print a summary of the linear model to find the Zipf's exponent
summary(model)

# Plot the percentage of all words vs unique words
word_counts <- colSums(dtm)   # Calculate the total word count for each word
unique_counts <- colSums(dtm > 0)   # Calculate the count of unique words
percent_unique <- unique_counts / sum(word_counts) * 100   # Calculate the percentage of unique words
percent_total <- cumsum(sort(word_counts, decreasing = TRUE)) / sum(word_counts) * 100   # Calculate the cumulative percentage of total words
plot(percent_total, percent_unique, type = "l", xlab = "Percentage of all words", ylab = "Percentage of unique words")   # Plot the graph

# Find the percentage of single words (Percent of Words appearing only once)
single_word_percentage <- sum(word_counts == 1) / length(word_counts) * 100   # Calculate the percentage of single words
cat("Percentage of single words:", single_word_percentage, "% \n")

# Plot cumulative percent vs the 100 most frequent words
top_words <- names(sort(word_counts, decreasing = TRUE)[1:100])   # Get the 100 most frequent words
cum_percent <- cumsum(sort(word_counts[top_words], decreasing = TRUE)) / sum(word_counts)   # Calculate the cumulative percentage of frequency for the top 100 words
plot(cum_percent, type = "l", xlab = "Rank of word", ylab = "Cumulative percentage of frequency")   # Plot the graph

# Find the difference between the model predicted frequency and the actual corpus frequency for the word "military"
actual_freq <- word_counts["military"]   # Get the actual frequency of the word "military"
rank_military <- rank(-word_counts)["military"]   # Get the rank of the word "military"
predicted_freq <- exp(predict(model, data.frame(log_rank = log(rank_military))))   # Calculate the predicted frequency of the word "military"
difference <- round(abs(predicted_freq - actual_freq), 2)   # Find the difference between the predicted and actual frequency and round it to 2 decimal places
cat("Actual frequency of 'military':", actual_freq, "\n")
cat("Predicted frequency of 'military':", predicted_freq, "\n")
cat("Difference between actual and predicted frequency of 'military':", difference, "\n")